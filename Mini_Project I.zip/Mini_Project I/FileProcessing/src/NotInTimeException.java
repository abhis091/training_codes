
public class NotInTimeException extends Exception {
	NotInTimeException(String msg){
		super(msg);
	}
}
