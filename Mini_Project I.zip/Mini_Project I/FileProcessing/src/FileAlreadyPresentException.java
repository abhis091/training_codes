
public class FileAlreadyPresentException extends Exception {
	FileAlreadyPresentException(String msg){
		super(msg);
	}
	
}
