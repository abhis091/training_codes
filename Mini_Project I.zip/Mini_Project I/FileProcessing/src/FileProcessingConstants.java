import java.io.File;

interface FileProcessingConstants{
	String inputFilesPath = "A:/RKIT Assignments/Mini_Project I/Input Files";
	String acceptedFilesPath = "A:/RKIT Assignments/Mini_Project I/Accepted Files";
	String xmlFilesPath = "A:/RKIT Assignments/Mini_Project I/XML Formats";
	String errorFilePath = "A:\\RKIT Assignments\\Mini_Project I\\Error Files";
	String outFilePath = "A:/RKIT Assignments/Mini_Project I/Output Files";
	File[] xmlFiles = new File(xmlFilesPath).listFiles();
}