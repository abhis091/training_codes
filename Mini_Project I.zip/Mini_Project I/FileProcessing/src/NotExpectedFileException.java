
public class NotExpectedFileException extends Exception {
	NotExpectedFileException(String msg){
		super(msg);
	}
}
