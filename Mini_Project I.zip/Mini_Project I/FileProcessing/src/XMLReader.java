import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class XMLReader {
	static Map<String,int[]> fieldMaxLengths = new HashMap<String,int[]>();
	static Map<String,Date> expectedFiles = new HashMap<String,Date>();
	static DocumentBuilderFactory factory;
	static DocumentBuilder docBuilder;
	static Document doc;
	static Node root;
	
	
	public static Map returnExpectedFiles() throws SAXException, IOException, ParseException, ParserConfigurationException  {
		int[] maxLengths = {};
		factory = DocumentBuilderFactory.newInstance();
		docBuilder = factory.newDocumentBuilder();
		for(File f : FileProcessingConstants.xmlFiles) {
			doc = docBuilder.parse(f.getPath());
			root = doc.getDocumentElement();
			
			NamedNodeMap rootAttr = root.getAttributes();
			String inFileName="";
			String outFileName="";
			String time="";
			for(int i=0;i<rootAttr.getLength();i++) {
				Node attrNode = rootAttr.item(i);
				String Name = attrNode.getNodeName();
				String value = attrNode.getNodeValue();
				if(Name.equalsIgnoreCase("name")) {
					inFileName=value;
				}
				if(Name.equalsIgnoreCase("timeToArrive")) {
					time=value;
				}
				if(Name.equalsIgnoreCase("outFileName")) {
					outFileName=value;
				}
			}
			LocalDate date = LocalDate.now();
			Date d = (Date)new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(date+" "+time+":00");
			
			NodeList rootChildList = root.getChildNodes();
			NodeList childListOfFormat = rootChildList.item(1).getChildNodes();
			maxLengths = new int[childListOfFormat.getLength()/2];
			int j=0;
			for(int i=1; i<childListOfFormat.getLength(); i+=2) {
				String value=childListOfFormat.item(i).getAttributes().item(0).getNodeValue();
				maxLengths[j]=Integer.parseInt(value);
				j++;
			}
			
			
			try {
				fieldMaxLengths.put(inFileName, maxLengths);
				expectedFiles.put(inFileName, d);
			}catch(Exception e) {
				System.out.println(e);
			}
		}
		
		return expectedFiles;
	}

	public static boolean validateFileContents(String[] fieldValues, String fileName) {
		
		if(fieldValues.length!=fieldMaxLengths.get(fileName).length ) {
			return false;
		}
		for(int i =0; i<fieldValues.length; i++) {
			if(fieldValues[i].length() > fieldMaxLengths.get(fileName)[i]) {
				return false;
			}
		}
		return true;
	}

}
