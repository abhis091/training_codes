import java.util.*;
import java.util.Map.Entry;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;


public class Worker implements Runnable{
	
	private Map<String,Date> expectedFiles = new HashMap<String,Date>();
	private File file;
	
	Worker(File f){
		super();
		try {
			expectedFiles = XMLReader.returnExpectedFiles();
			Thread.currentThread();
			Thread.sleep(1000);
		}catch(Exception e) {
			System.out.println(e.toString());
		}
		this.file = f;
	}
	
	public Map<String, Date> getExpectedFiles() {
		return expectedFiles;
	}

	public void setExpectedFiles(Map<String, Date> expectedFiles) {
		this.expectedFiles = expectedFiles;
	}

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public void run(){
		try {
			if(isExpectedFile(file.getName())) {
				try {
					if(isInTime(file)) {
						try {
							if(isFileAvailable(file)) {
								new Thread(new Processor(file.getName())).start();
							}else {
								throw new FileAlreadyPresentException("This file is Already Present...\nDeleting File: "+file.getName());
							}
						}catch(FileAlreadyPresentException e) {
							System.out.println(e);
							file.delete();
							return;
						}
					}
					else {
						throw new NotInTimeException("This file is late submitted...\nDeleting File: "+file.getName());
					}
				}catch (NotInTimeException e) {
					System.out.println(e);
					file.delete();
					return;
				}
			}
			else {
				throw new NotExpectedFileException("This file is Not Expected...\nDeleting File: "+file.getName());
			}
		}catch (NotExpectedFileException e) {
			System.out.println(e);
			file.delete();
			return;
		}
		
	}
	
	private boolean isExpectedFile(String fileName) {
		for(Entry<String, Date> entry : expectedFiles.entrySet()) {
			if(entry.getKey().equalsIgnoreCase(fileName)) {
				return true;
			}
		}
		return false;
	}
	
	private boolean isInTime(File file) {
		for (Entry<String, Date> entry : expectedFiles.entrySet()) {
	        if (entry.getKey().equals(file.getName())) {
	        	long time = file.lastModified();
				Calendar cal = new GregorianCalendar();
				cal.setTimeInMillis(time);
				Date date = cal.getTime();
				Date expectedDate = entry.getValue();
				if(date.before(expectedDate)) {
					return true;
				}
	        }
	    }
		return false;
	}
	
	private boolean isFileAvailable(File file){
		try {
			Files.move(Paths.get(FileProcessingConstants.inputFilesPath+"/"+file.getName()),
					Paths.get(FileProcessingConstants.acceptedFilesPath+"/"+file.getName()));
		}catch(IOException e) {
			return false;
		}
		return true;
	}
}
