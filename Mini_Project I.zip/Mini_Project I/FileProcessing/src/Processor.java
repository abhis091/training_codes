import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Processor implements Runnable{
	private String fileName;
	
	Processor(String fName){
		this.fileName = fName;
	}
	
	public void run() {
		try{
			FileReader fr = new FileReader(new File(FileProcessingConstants.acceptedFilesPath+"/"+fileName));
			BufferedReader br = new BufferedReader(fr);
			String line="";
			int lineCount=0;
			while((line=br.readLine())!=null) {
				lineCount++;
				String[] fieldValues = line.split(",");
				String[] outFile= fileName.split("\\.");;
				if(XMLReader.validateFileContents(fieldValues, fileName)) {
					String fName = outFile[0]+".out."+outFile[1];
					File out = new File(FileProcessingConstants.outFilePath+"/"+fName);
					out.createNewFile();
					Files.write(Paths.get(out.getPath()), (line+"\n").getBytes(), StandardOpenOption.APPEND);
				}else {
					try {
						String fn = outFile[0]+".error."+outFile[1];
						File errFile = new File(FileProcessingConstants.errorFilePath+"/"+fn);
						errFile.createNewFile();
					    Files.write(Paths.get(errFile.getPath()), ("Line:"+lineCount+":"+line+"\n").getBytes(), StandardOpenOption.APPEND);
					}catch (IOException e) {
					    System.out.println(e.toString());
					}
				}
			}
		}catch(IOException e) {
			System.out.println(e.toString());
		}
		
	}
	
	
	
}
