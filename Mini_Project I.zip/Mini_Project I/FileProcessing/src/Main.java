import java.io.*;

public class Main {
	private static int totalFileCount = 0;
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		File inputDir = new File(FileProcessingConstants.inputFilesPath);
		while(true) {
			File[] inputFiles = inputDir.listFiles();
			int newFileCount = inputFiles.length;
			totalFileCount = newFileCount;
			Thread[] th = new Thread[newFileCount];
			if(totalFileCount>0) {
				for(int i=0;i<newFileCount;i++) {
					th[i] = new Thread(new Worker(inputFiles[i]));
					th[i].start();
				}
				for(Thread t : th) {
					t.join();
				}
			}
		}
		
	}
}