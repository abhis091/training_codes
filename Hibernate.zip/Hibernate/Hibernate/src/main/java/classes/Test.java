package classes;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		Transaction txn = session.beginTransaction();
		/*Student std = new Student();
		Address addr = new Address();
		addr.setCity("Kolhapur");
		addr.setPin(416119);
		std.setAddr(addr);
		std.setFname("Abhi");
		std.setLname("Sawant");
		std.setRollNo(1909);
		session.save(std);*/
		
		Student s = session.load(Student.class, 1909);
		System.out.println(s.rollNo);
		txn.commit();
		
		Transaction txn1 = session.beginTransaction();
		
		Student std = session.load(Student.class,1909);
		std.setFname("Abhishek");
		txn1.commit();
		
		Transaction t = session.beginTransaction();
		Student s1 = session.load(Student.class, 1909);
		System.out.println(s1.getFname());
		session.close();
	}

}
