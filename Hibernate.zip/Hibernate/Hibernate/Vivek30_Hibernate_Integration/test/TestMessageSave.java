

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import hello.Message;

@Transactional
public class TestMessageSave {
	
	public static void main(String[] args){
		Message msg = new Message(new Long(12345),"SpringHello World","Spring HelloMessageDescription","Spring HelloMessage ");
		ApplicationContext ctx = new ClassPathXmlApplicationContext("application-list.config.xml");
		
	    HibernateTemplate template = ctx.getBean(HibernateTemplate.class);
	    template.save(msg);
	    
		//We use HibernateTeamplate or use following code note you need to mark the Transaction boundaries in this case.
	    msg=new Message(1l,"hibernateNative","Hibnative","HibNative");
		SessionFactory sessionFactory = (SessionFactory)ctx.getBean("sessionFactory");
		Session session = sessionFactory.getCurrentSession();
		System.out.println("Session Class "+session);
		Transaction txn = session.beginTransaction();
		session.save(msg);
		txn.commit(); 
	}

}
