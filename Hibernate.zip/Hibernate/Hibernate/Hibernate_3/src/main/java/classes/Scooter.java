package classes;

public class Scooter extends Vehicle{
	private String regNo;
	private String name;
	
	@Override
	public String toString() {
		return "Scooter [regNo=" + regNo + ", name=" + name + "]";
	}

	public String getRegNo() {
		return regNo;
	}

	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
