package classes;

public class Car extends Vehicle {
	private String regNo;
	private String variant;
	
	public String getRegNo() {
		return regNo;
	}

	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}

	public String getVariant() {
		return variant;
	}

	public void setVariant(String variant) {
		this.variant = variant;
	}

	@Override
	public String toString() {
		return "Car [regNo=" + regNo + ", variant=" + variant + "]";
	}
	
	
}
