package classes;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		Transaction txn = session.beginTransaction();

		Scooter sc = new Scooter();
		sc.setvNo("MH09AS1999");
		sc.setRegNo("42479914JADJK237");
		sc.setName("Activa");
		Car cr = new Car();
		cr.setRegNo("2384789JDJAJ4399");
		cr.setVariant("Diesel");
		cr.setvNo("MH09SA1999");
		
		session.save(sc);
		session.save(cr);
		
		txn.commit();
		session.close();
	}

}
