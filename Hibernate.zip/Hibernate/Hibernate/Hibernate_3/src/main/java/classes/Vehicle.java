package classes;

public class Vehicle {
	private int id;
	private String vNo;

	@Override
	public String toString() {
		return "Vehicle [id=" + id + ", vNo=" + vNo +  "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getvNo() {
		return vNo;
	}

	public void setvNo(String vNo) {
		this.vNo = vNo;
	}
	
}
