package classes;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		Transaction txn = session.beginTransaction();
		
		Student std = new Student();
		Address addr = new Address();
		addr.setId(2000);
		addr.setCity("Kolhapur");
		addr.setPin(416119);
		std.setAddr(addr);
		std.setFname("Abhi");
		std.setLname("Sawant");
		std.setRollNo(1902);
		session.save(std);
		
		Student s = session.get(Student.class, 2000);
		System.out.println(s);
		txn.commit();
		session.close();
	}

}
