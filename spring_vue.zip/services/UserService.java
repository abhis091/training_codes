package services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import classFiles.User;
import repos.DBRepository;

@Service  //same as creating a bean
public class UserService {
	@Autowired
	DBRepository repo;
	
	public List<User> findAll() {
		return (List<User>) repo.findAll();
	}

	public void saveData(User user) {
		repo.save(new User(user.getName(),user.getMail(),user.getPass(),user.getMob(),user.getCity()));
	}
}