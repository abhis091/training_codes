package repos;

import org.springframework.data.repository.CrudRepository;

import classFiles.User;

public interface DBRepository extends CrudRepository<User, Integer> {

}
